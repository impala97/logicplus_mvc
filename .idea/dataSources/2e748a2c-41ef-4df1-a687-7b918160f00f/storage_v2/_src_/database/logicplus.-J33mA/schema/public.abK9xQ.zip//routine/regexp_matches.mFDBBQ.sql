CREATE FUNCTION regexp_matches(citext, citext)
  RETURNS SETOF text[]
IMMUTABLE
STRICT
ROWS 1
LANGUAGE SQL
AS $$
SELECT pg_catalog.regexp_matches( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;

